<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ContractActivity extends Model
{
    protected $fillable = ['contract_id', 'user_id', 'action', 'details'];

    protected $casts = [
        'details' => 'array',
    ];

    public function contract()
    {
        return $this->belongsTo(Contract::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
