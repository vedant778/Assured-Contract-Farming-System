<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Contract;
use App\Models\Bid;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    public function index()
    {
        $user = Auth::user();
        
        if ($user->isFarmer()) {
            $contracts = Contract::where('farmer_id', $user->id)->with('crop', 'bids.buyer')->get();
            
            // Analytics Data
            $totalContracts = $contracts->count();
            $activeContracts = $contracts->where('status', 'active')->count();
            $completedContracts = $contracts->where('status', 'completed')->count();
            
            // Calculate Total Revenue from accepted bids
            $totalRevenue = 0;
            foreach ($contracts as $contract) {
                $acceptedBid = $contract->bids->where('status', 'accepted')->first();
                if ($acceptedBid) {
                    $totalRevenue += ($acceptedBid->amount * $contract->quantity);
                }
            }

            // Data for charts
            $statusChartData = [
                $contracts->where('status', 'pending')->count(),
                $activeContracts,
                $completedContracts
            ];

            return view('dashboard', compact(
                'contracts', 'user', 'totalContracts', 'activeContracts', 'completedContracts', 'totalRevenue', 'statusChartData'
            ));

        } elseif ($user->isBuyer()) {
            $bids = Bid::where('buyer_id', $user->id)->with('contract.crop', 'contract.farmer')->get();
            
            // Analytics Data
            $totalBids = $bids->count();
            $acceptedBids = $bids->where('status', 'accepted')->count();
            $pendingBids = $bids->where('status', 'pending')->count();
            
            // Calculate Total Spent
            $totalSpent = 0;
            foreach ($bids->where('status', 'accepted') as $bid) {
                $totalSpent += ($bid->amount * $bid->contract->quantity);
            }

            // Data for charts
            $bidStatusData = [
                $pendingBids,
                $acceptedBids,
                $bids->where('status', 'rejected')->count()
            ];

            return view('dashboard', compact(
                'bids', 'user', 'totalBids', 'acceptedBids', 'totalSpent', 'bidStatusData'
            ));
        }

        return view('dashboard', compact('user'));
    }
}
