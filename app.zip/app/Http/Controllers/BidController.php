<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Contract;
use App\Models\Bid;
use App\Models\Payment;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\StoreBidRequest;
use App\Events\BidPlaced;
use App\Events\BidAccepted;

class BidController extends Controller
{
    public function store(StoreBidRequest $request, Contract $contract)
    {
        $bid = Bid::create([
            'contract_id' => $contract->id,
            'buyer_id' => Auth::id(),
            'amount' => $request->amount,
            'status' => 'pending',
        ]);

        event(new BidPlaced($bid));

        return back()->with('success', 'Bid submitted successfully.');
    }

    public function accept(Bid $bid)
    {
        $contract = $bid->contract;

        if (Auth::id() !== $contract->farmer_id) {
            abort(403);
        }

        $bid->update(['status' => 'accepted']);
        $contract->update(['status' => 'active']);

        // Reject other bids
        Bid::where('contract_id', $contract->id)->where('id', '!=', $bid->id)->update(['status' => 'rejected']);

        // Create Payment stub
        Payment::create([
            'contract_id' => $contract->id,
            'payer_id' => $bid->buyer_id,
            'payee_id' => $contract->farmer_id,
            'amount' => $bid->amount * $contract->quantity,
            'status' => 'pending',
        ]);

        event(new BidAccepted($bid));

        return back()->with('success', 'Bid accepted. Contract is now active.');
    }

    public function reject(Bid $bid)
    {
        $contract = $bid->contract;

        if (Auth::id() !== $contract->farmer_id) {
            abort(403);
        }

        $bid->update(['status' => 'rejected']);

        return back()->with('success', 'Bid rejected.');
    }
}
