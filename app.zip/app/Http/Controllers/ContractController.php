<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Contract;
use App\Models\Crop;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\StoreContractRequest;
use App\Events\ContractCreated;

class ContractController extends Controller
{
    public function index(Request $request)
    {
        if (!Auth::user()->isBuyer()) {
            abort(403);
        }

        $query = Contract::pending()->with('crop', 'farmer', 'bids');

        // Filter by Crop
        if ($request->has('crop_id') && $request->crop_id != '') {
            $query->where('crop_id', $request->crop_id);
        }

        // Filter by Min Price
        if ($request->has('min_price') && $request->min_price != '') {
            $query->where('price_per_unit', '>=', $request->min_price);
        }

        // Filter by Max Price
        if ($request->has('max_price') && $request->max_price != '') {
            $query->where('price_per_unit', '<=', $request->max_price);
        }

        // Sorting
        if ($request->has('sort')) {
            if ($request->sort == 'price_asc') {
                $query->orderBy('price_per_unit', 'asc');
            } elseif ($request->sort == 'price_desc') {
                $query->orderBy('price_per_unit', 'desc');
            } else {
                $query->latest();
            }
        } else {
            $query->latest();
        }

        $contracts = $query->get();
        $crops = Crop::all();

        return view('contracts.index', compact('contracts', 'crops'));
    }

    public function create()
    {
        if (Auth::user()->role !== 'farmer') {
            abort(403, 'Unauthorized action.');
        }
        $crops = Crop::all();
        return view('contracts.create', compact('crops'));
    }

    public function store(StoreContractRequest $request)
    {
        $contract = Contract::create([
            'farmer_id' => Auth::id(),
            'crop_id' => $request->crop_id,
            'quantity' => $request->quantity,
            'price_per_unit' => $request->price_per_unit,
            'delivery_date' => $request->delivery_date,
            'status' => 'pending',
        ]);

        event(new ContractCreated($contract));

        return redirect()->route('dashboard')->with('success', 'Contract proposed successfully.');
    }

    public function show(Contract $contract)
    {
        $contract->load('crop', 'farmer', 'bids.buyer');
        return view('contracts.show', compact('contract'));
    }
}
