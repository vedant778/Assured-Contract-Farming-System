<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;

class StoreContractRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return $this->user()->isFarmer();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'crop_id' => ['required', 'exists:crops,id'],
            'quantity' => ['required', 'numeric', 'min:1'],
            'price_per_unit' => ['required', 'numeric', 'min:0.01'],
            'delivery_date' => ['required', 'date', 'after:today'],
        ];
    }
}
